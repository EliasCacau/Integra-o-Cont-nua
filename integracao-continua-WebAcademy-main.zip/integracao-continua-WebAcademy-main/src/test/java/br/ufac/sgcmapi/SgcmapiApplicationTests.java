package br.ufac.sgcmapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SgcmapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
