package br.ufac.sgcmapi.model;

public enum EGrupoSanguineo {

    A_POSITIVO,
    A_NEGATIVO,
    B_POSITIVO,
    B_NEGATIVO,
    AB_POSITIVO,
    AB_NEGATIVO,
    O_POSITIVO,
    O_NEGATIVO;
    
}
