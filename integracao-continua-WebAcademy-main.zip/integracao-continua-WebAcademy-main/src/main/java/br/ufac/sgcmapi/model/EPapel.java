package br.ufac.sgcmapi.model;

public enum EPapel {

    ROLE_ADMIN,
    ROLE_ATENDENTE

}
