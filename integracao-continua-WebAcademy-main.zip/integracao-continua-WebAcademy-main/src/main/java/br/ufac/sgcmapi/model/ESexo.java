package br.ufac.sgcmapi.model;

public enum ESexo {

    M, F;
    
}
